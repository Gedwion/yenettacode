-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2023 at 11:24 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taskmanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(60) NOT NULL,
  `address` varchar(255) NOT NULL,
  `Is_Active` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `address`, `Is_Active`) VALUES
(1, 'Gedion', 'Gedionsisay@gmail.com', '$2y$12$4zHYXI1hiob5S/Kn51Ae5u8OrhdPM5TwfA4btGek7q4evs/e8G/ri', 'Asela', 1),
(2, 'shalom', 'shalomtufa11@gmail.com', '$2y$12$x5KJznZmKTdgs/v4C9FXze6qNK4SS371hJV4AFJ4eCbPR3JrlnvsG', 'Asela', 1),
(3, 'Gedion1', 'gedion1@gmail.com', '$2y$12$UOQXE90LkgFedVk0Vacg6.fgOUDXV/zpvfnGXg1fPKaM5W8CIJEXq', 'adama', 1),
(4, 'Gedion11', 'gedions@gmail.com', '$2y$12$8HqZi57LCmaqWeus0HDqiOUsqik5gTl/rZKFMKVV9L3uMjQUuikk2', 'adiss abeba', 0),
(5, 'Gedi', 'sss@gmail.com', '$2y$12$mSr45Ros2JxzwKcLHDaOGelCCoTRFhB7DJPHMWrIuYDdnZhLm8G86', 'adama', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
