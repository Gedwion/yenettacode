<!-- dashboard.php -->
<?php
if (isset($_POST['login'])) {
   $login = $_POST['login'];
   $password = $_POST['password'];
   $remember = $_POST['remember'];
   $login_error = $_POST['login_error'];
   }    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    h1{
        margin-left: 300px;
        margin-top: 300px;
    }
    body{
        background-color: #17a2b1;
    }
</style>
<body>
   <h1>Welcome TO Computer Security Project</h1> 
   
</body>
</html>