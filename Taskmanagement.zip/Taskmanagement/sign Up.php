<?php 
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login'])==1)
  { 
header('location:index.php');
}
else{
if(isset($_POST['submit']))
{
$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];
$options = ['cost' => 12];
$hashedpass=password_hash($password, PASSWORD_BCRYPT, $options);
$address=$_POST['address'];

$username1=mysqli_query($con,"select username from user where username='$username' ");

    $email1=mysqli_query($con,"select email from user where email='$email' ");
if(mysqli_num_rows($username1)>0){
    echo "<script>alert('username Already Exist');</script>";
}

elseif(mysqli_num_rows($email1)>0){
    echo "<script>alert('Email Already Exist');</script>";
}
elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    echo "<script>alert(' Invalid Email Adress');</script>";
}
else
{
$status=1;
$query=mysqli_query($con,"insert into user(username,email, password, address) values('$username','$email' ,'$hashedpass','$address')");
if($query)
{
$msg="successfully added ";
}
else{
$error="Something went wrong . Please try again.";    
}
}
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="developed for dvlca news posts">
        <meta name="author" content="dvlca web">
       
        <title>CS |Registration</title>
        <link href="plugins/summernote/summernote.css" rel="stylesheet" />
        <link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="plugins/jquery.filer/css/jquery.filer.css" rel="stylesheet" />
        <link href="assets/css/form.css" rel="stylesheet" />
        <link href="plugins/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet" />
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
        <script src="assets/js/modernizr.min.js"></script>
        <script type="text/javascript">
function valid()
{
 if(document.addadmin.username.value=="")
{
alert(" username Field is Empty !!");
document.addadmin.username.focus();
return false;
}
else if(document.addadmin.email.value=="")
{
alert("Email Filed is Empty !!");
document.addadmin.email.focus();
return false;
}
else if(document.addadmin.password.value=="")
{
alert(" Password Field is Empty !!");
document.addadmin.password.focus();
return false;
}
else if(document.addadmin.password.length < 8) 
{
    alert(" **Password length must be atleast 8 characters");
    document.addadmin.password.focus();
     return false;
 }
else if(document.addadmin.cpassword.value=="")
{
alert("Confirm Password Filed is Empty !!");
document.addadmin.password.focus();
return false;
}
else if(document.addadmin.password.value!= document.addadmin.cpassword.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.addadmin.cpassword.focus();
return false;
}
else if(document.addadmin.per_role.value=="")

return true;
}
</script>
    </head>
    <body class="fixed-left">
        <div id="wrapper">
            
                <div class="content">
                    <div class="container">

<div class="row">
<div class="col-sm-6">  
<?php if($msg){ ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo htmlentities($msg);?>
</div>
<?php } ?>
<?php if($error){ ?>
<div class="alert alert-danger" role="alert">
<strong>Oh !</strong> <?php echo htmlentities($error);?></div>
<?php } ?>
</div>
</div>
                        <div class="row">
                            <div class="col-md-5 col-md-offset-1">
                                <div class="p-8">
                                    <div class="container" >
<form name="addadmin" method="post" enctype="multipart/form-data" onSubmit="return valid();">
 <div class="form-group m-b-20">
<label for="exampleInputEmail1"style="padding-top: 20px;">User Name</label>
<input type="text" class="form-control" id="username" name="username" placeholder="Enter LastName" required>
<label for="exampleInputEmail1"style="padding-top: 20px;">Email</label>
<input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required>
<label for="exampleInputEmail1"style="padding-top: 20px;">Password</label>
<div class="field">
               <input  type="password" name="password" id="password" placeholder="Enter password">
      
            </div  >
            
            
<label for="exampleInputEmail1"style="padding-top: 20px;">Confirm Password</label>
<div class="field">
<input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Cofirm Pass" required>
            </div>
            <label for="exampleInputEmail1"style="padding-top: 20px;">Address:</label>
<div class="field">
<input type="text" class="form-control" id="address" name="address" placeholder="Enter Address" required>
            </div>     

</div>
<button type="submit" name="submit" class="btn btn-success waves-effect waves-light">Save</button>
 
                                        </form>
                                    </div>
                                </div> 
                            </div> 
                            
                        </div>
                       
  <script src="plugins/switchery/switchery.min.js"></script>
        <script src="plugins/summernote/summernote.min.js"></script>
       
    </body>
    
</html>
<?php } ?>
  